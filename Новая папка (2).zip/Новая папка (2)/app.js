(() => {
  const $ = (id) => document.getElementById(id);
  const downloadEl = $("downloadValue");
  const uploadEl = $("uploadValue");
  const latencyUnloadedEl = $("latencyUnloaded");
  const latencyLoadedEl = $("latencyLoaded");
  const statusEl = $("status");
  const btnStart = $("btnStart");
  const btnStop = $("btnStop");
  const btnMore = $("btnMore");
  const moreSection = $("moreSection");
  const btnSettings = $("btnSettings");
  const settingsDialog = $("settingsDialog");
  const inputConnections = $("connections");
  const inputDuration = $("duration");
  const chkLoadedLatency = $("measureLoadedLatency");

  let controllers = [];
  let running = false;

  function setStatus(text) {
    statusEl.textContent = text;
  }

  function formatMbps(bitsPerSecond) {
    const mbps = bitsPerSecond / (1024 * 1024);
    return Math.max(0, mbps).toFixed(mbps >= 100 ? 0 : mbps >= 10 ? 1 : 2);
  }

  function jitter() {
    return Math.floor(Math.random() * 1e7) + 1e6; // 1MB..~11MB
  }

  function makeAbortController() {
    const c = new AbortController();
    controllers.push(c);
    return c;
  }

  function abortAll() {
    controllers.forEach((c) => c.abort());
    controllers = [];
  }

  async function measureLatency(samples = 5, loaded = false) {
    const results = [];
    for (let i = 0; i < samples; i++) {
      const start = performance.now();
      try {
        const c = makeAbortController();
        const url = `https://speed.cloudflare.com/__down?bytes=1&ts=${crypto.randomUUID()}`;
        const res = await fetch(url, {
          cache: "no-store",
          signal: c.signal,
          // If loaded latency requested, allow immediate contention
          priority: loaded ? "low" : "high",
        });
        if (!res.ok) throw new Error("latency probe failed");
        await res.arrayBuffer();
        const dt = performance.now() - start;
        results.push(dt);
      } catch (_) {
        results.push(1000);
      }
    }
    results.sort((a, b) => a - b);
    const median = results[Math.floor(results.length / 2)] || 0;
    return Math.round(median);
  }

  async function drainResponse(res) {
    const reader = res.body.getReader();
    let received = 0;
    // Read without buffering whole body to avoid memory bloat
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      received += value.byteLength;
    }
    return received;
  }

  async function downloadWorker(stopAtTs, progressCb) {
    let bytes = 0;
    while (running && performance.now() < stopAtTs) {
      const size = jitter();
      const c = makeAbortController();
      const url = `https://speed.cloudflare.com/__down?bytes=${size}&cacheBust=${crypto.randomUUID()}`;
      try {
        const start = performance.now();
        const res = await fetch(url, { cache: "no-store", signal: c.signal });
        if (!res.ok || !res.body) throw new Error("download failed");
        const got = await drainResponse(res);
        bytes += got;
        progressCb(bytes, performance.now() - start);
      } catch (_) {
        // ignore and retry next loop
      }
    }
    return bytes;
  }

  async function runDownload(connections, durationSec) {
    running = true;
    const stopAt = performance.now() + durationSec * 1000;
    let totalBytes = 0;
    let lastUpdate = performance.now();

    const progress = (bytesSinceWorkerStart) => {
      // Throttle UI updates
      const now = performance.now();
      if (now - lastUpdate > 150) {
        lastUpdate = now;
        const elapsed = Math.max(0.001, (now - (stopAt - durationSec * 1000)) / 1000);
        const bps = (totalBytes + bytesSinceWorkerStart) * 8 / elapsed;
        downloadEl.textContent = formatMbps(bps);
      }
    };

    const workers = Array.from({ length: connections }, () => downloadWorker(stopAt, progress));
    const results = await Promise.all(workers);
    totalBytes = results.reduce((a, b) => a + b, 0);

    const totalTimeSec = durationSec;
    const bps = (totalBytes * 8) / totalTimeSec;
    downloadEl.textContent = formatMbps(bps);
  }

  async function runUpload(durationSec = 7) {
    const stopAt = performance.now() + durationSec * 1000;
    let totalBytes = 0;
    let lastUpdate = performance.now();

    // Use a reusable random buffer ~1MB
    const base = new Uint8Array(1024 * 1024);
    crypto.getRandomValues(base);

    while (running && performance.now() < stopAt) {
      const mult = 1 + Math.floor(Math.random() * 8); // 1..8 MB per POST
      const payload = new Uint8Array(base.buffer.slice(0, base.byteLength * mult));
      const c = makeAbortController();
      try {
        const start = performance.now();
        const res = await fetch("https://speed.cloudflare.com/__up", {
          method: "POST",
          cache: "no-store",
          body: payload,
          headers: { "content-type": "application/octet-stream" },
          signal: c.signal,
        });
        if (!res.ok) throw new Error("upload failed");
        totalBytes += payload.byteLength;
        const now = performance.now();
        if (now - lastUpdate > 150) {
          lastUpdate = now;
          const elapsed = Math.max(0.001, (now - (stopAt - durationSec * 1000)) / 1000);
          const bps = (totalBytes * 8) / elapsed;
          uploadEl.textContent = formatMbps(bps);
        }
      } catch (_) {
        // ignore
      }
    }
  }

  function setRunningUI(isRunning) {
    btnStart.disabled = isRunning;
    btnStop.disabled = !isRunning;
  }

  async function runTestSuite() {
    const connections = Math.min(16, Math.max(1, parseInt(inputConnections.value || "6", 10)));
    const duration = Math.min(30, Math.max(3, parseInt(inputDuration.value || "10", 10)));

    // Reset UI
    downloadEl.textContent = "0";
    uploadEl.textContent = "0";
    latencyUnloadedEl.textContent = "0";
    latencyLoadedEl.textContent = "0";
    setRunningUI(true);
    setStatus("Идёт тест загрузки…");

    try {
      const unloaded = await measureLatency(5, false);
      latencyUnloadedEl.textContent = String(unloaded);
    } catch (_) {}

    await runDownload(connections, duration);

    if (chkLoadedLatency.checked) {
      setStatus("Измерение задержки под нагрузкой…");
      try {
        const loaded = await measureLatency(5, true);
        latencyLoadedEl.textContent = String(loaded);
      } catch (_) {}
    }

    setStatus("Идёт тест отдачи…");
    await runUpload(Math.max(5, Math.floor(duration * 0.7)));

    setStatus("Готово");
  }

  function start() {
    if (running) return;
    running = true;
    abortAll();
    runTestSuite().finally(() => {
      running = false;
      setRunningUI(false);
      abortAll();
    });
  }

  function stop() {
    if (!running) return;
    setStatus("Остановка…");
    running = false;
    abortAll();
    setRunningUI(false);
    setStatus("Остановлено");
  }

  // Controls
  btnStart.addEventListener("click", start);
  btnStop.addEventListener("click", stop);
  btnMore.addEventListener("click", () => {
    const show = moreSection.classList.contains("hidden");
    moreSection.classList.toggle("hidden");
    moreSection.setAttribute("aria-hidden", String(!show));
    btnMore.textContent = show ? "Скрыть" : "Показать больше";
  });
  btnSettings.addEventListener("click", () => settingsDialog.showModal());
  $("saveSettings").addEventListener("click", () => settingsDialog.close());

  // Optional: auto-start on load similar to fast.com
  // start();
})();

